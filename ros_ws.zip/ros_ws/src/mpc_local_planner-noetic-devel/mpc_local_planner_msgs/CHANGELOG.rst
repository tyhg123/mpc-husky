^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mpc_local_planner_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.3 (2020-06-09)
------------------
* Changed minimum CMake version to 3.1
* Contributors: Christoph Rösmann

0.0.2 (2020-03-12)
------------------

0.0.1 (2020-02-20)
------------------
* First release
* Contributors: Christoph Rösmann
